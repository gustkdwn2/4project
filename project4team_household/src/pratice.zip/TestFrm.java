package pratice;

import javax.swing.JFrame;

public class TestFrm extends JFrame{
    public TestFrm() {
        setSize(400, 400);
        setVisible(true);
    }
}

