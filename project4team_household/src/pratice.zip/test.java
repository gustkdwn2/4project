package pratice;

import javax.swing.JFrame;

public class test extends JFrame{
	public test() {
        setSize(400, 400);
        setVisible(true);
    }
}